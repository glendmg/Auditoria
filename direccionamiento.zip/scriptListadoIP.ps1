﻿# ==============================
# Script: scriptListadoIP_Geo.ps1
# Compatible con Windows PowerShell 5.1
# ==============================

$CarpetaDestino = "C:\GPO"

if (!(Test-Path $CarpetaDestino)) {
    New-Item -ItemType Directory -Path $CarpetaDestino | Out-Null
}

$Equipo = $env:COMPUTERNAME
$FechaEjecucion = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$FechaArchivo = Get-Date -Format "ddMMyyyy-HHmm"

# ==============================
# BLOQUE: DÍA DE LA SEMANA EN ESPAÑOL
# ==============================
$nombresDias = @{
    "Monday"    = "Lunes"
    "Tuesday"   = "Martes"
    "Wednesday" = "Miércoles"
    "Thursday"  = "Jueves"
    "Friday"    = "Viernes"
    "Saturday"  = "Sábado"
    "Sunday"    = "Domingo"
}
$DiaSemana = $nombresDias[(Get-Date).DayOfWeek.ToString()]
# ==============================

try {
    $NumeroSerie = (Get-CimInstance Win32_BIOS).SerialNumber
}
catch {
    $NumeroSerie = "No disponible"
}

# ==============================
# BLOQUE DE GEOLOCALIZACIÓN (Mejorado)
# ==============================
Add-Type -AssemblyName System.Device
# Se solicita alta precisión (High) para forzar la triangulación Wi-Fi/GPS
$GeoWatcher = New-Object System.Device.Location.GeoCoordinateWatcher([System.Device.Location.GeoPositionAccuracy]::High)

$GeoWatcher.Start()

Write-Host "Consultando el sensor de ubicación de Windows..." -ForegroundColor Cyan

# Espera dinámica: aguarda hasta que el estado sea 'Ready' o pasen 15 segundos
$intentos = 0
while (($GeoWatcher.Status -ne 'Ready') -and ($intentos -lt 15)) {
    Start-Sleep -Seconds 1
    $intentos++
}

$Ubicacion = $GeoWatcher.Position.Location

if (($Ubicacion -ne $null) -and ($Ubicacion.IsUnknown -eq $false)) {
    $lat = $Ubicacion.Latitude
    $lon = $Ubicacion.Longitude
    $enlaceMaps = "https://www.google.com/maps?q=$lat,$lon"
    
    Write-Host "`n=== Ubicación Real Obtenida ===" -ForegroundColor Green
    Write-Host "Latitud:  $lat"
    Write-Host "Longitud: $lon"
} else {
    $lat = "Desconocido"
    $lon = "Desconocido"
    $enlaceMaps = "Desconocido"
    
    Write-Warning "`nNo se pudo obtener la ubicación exacta después de 15 segundos. Verifica permisos de Windows y Wi-Fi."
}

$GeoWatcher.Stop()
# ==============================

function Obtener-WAN {
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

        [System.Net.WebRequest]::DefaultWebProxy = [System.Net.WebRequest]::GetSystemWebProxy()
        [System.Net.WebRequest]::DefaultWebProxy.Credentials = [System.Net.CredentialCache]::DefaultNetworkCredentials
    }
    catch {}

    $urls = @(
        "https://api.ipify.org",
        "https://ifconfig.me/ip",
        "https://checkip.amazonaws.com"
    )

    $ultimoError = ""

    for ($intento = 1; $intento -le 6; $intento++) {

        foreach ($url in $urls) {
            try {
                $ip = (Invoke-RestMethod -Uri $url -TimeoutSec 20 -ProxyUseDefaultCredentials).ToString().Trim()

                if ($ip -match '^\d{1,3}(\.\d{1,3}){3}$') {
                    return $ip
                }
            }
            catch {
                $ultimoError = $_.Exception.Message
            }
        }

        try {
            $resultado = nslookup myip.opendns.com resolver1.opendns.com 2>$null

            $ips = [regex]::Matches(($resultado -join "`n"), '\b(?:\d{1,3}\.){3}\d{1,3}\b') |
                ForEach-Object { $_.Value } |
                Where-Object {
                    $_ -ne "208.67.222.222" -and
                    $_ -ne "208.67.220.220"
                } |
                Select-Object -Unique

            if ($ips) {
                return ($ips | Select-Object -Last 1)
            }
        }
        catch {
            $ultimoError = $_.Exception.Message
        }

        Start-Sleep -Seconds 10
    }

    return "Error consultando WAN: $ultimoError"
}

function Obtener-DatosIP {
    $ips = @(Get-NetIPAddress -AddressFamily IPv4 |
    Where-Object {
        $_.IPAddress -notlike "169.254*" -and
        $_.IPAddress -ne "127.0.0.1"
    } |
    Select-Object InterfaceAlias, IPAddress)

    $wanIP = Obtener-WAN

    $wan = [PSCustomObject]@{
        InterfaceAlias = "IP pública/WAN"
        IPAddress      = $wanIP
    }

    $ips + $wan | ForEach-Object {
        [PSCustomObject]@{
            Equipo          = $Equipo
            FechaEjecucion  = $FechaEjecucion
            DiaSemana       = $DiaSemana
            NumeroSerie     = $NumeroSerie
            InterfaceAlias  = $_.InterfaceAlias
            IPAddress       = $_.IPAddress
            Latitud         = $lat
            Longitud        = $lon
            EnlaceMaps      = $enlaceMaps
        }
    }
}

try {
    $NombreArchivo = "Listado_IP_${Equipo}_${FechaArchivo}.CSV"
    $RutaArchivo = Join-Path $CarpetaDestino $NombreArchivo

    # 1. Generar el archivo
    $datos = Obtener-DatosIP
    $datos | Export-Csv -Path $RutaArchivo -NoTypeInformation -Encoding UTF8

    Write-Host "Archivo generado correctamente: $RutaArchivo" -ForegroundColor Green

    # 2. Ejecutar el script VBS
    $RutaVBS = "C:\GPO\copiarauditoriaip.vbs"
    
    if (Test-Path $RutaVBS) {
        Write-Host "Ejecutando script de auditoría ($RutaVBS)..." -ForegroundColor Cyan
        Start-Process "wscript.exe" -ArgumentList "`"$RutaVBS`""
    } else {
        Write-Warning "El archivo VBS no se encontró en la ruta especificada ($RutaVBS). Se omitió este paso."
    }
}
catch {
    Write-Host "Error general del script: $($_.Exception.Message)" -ForegroundColor Red
}